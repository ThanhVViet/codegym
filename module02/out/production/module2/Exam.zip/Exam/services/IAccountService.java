package Exam.services;

import Exam.models.AccountBank;

public interface IAccountService extends BaseFunction<AccountBank> {
}
