function StudentUpdate() {

    return (
        <>
            <h1>Cập nhật học sinh</h1>
        </>
    )
}

export default StudentUpdate;